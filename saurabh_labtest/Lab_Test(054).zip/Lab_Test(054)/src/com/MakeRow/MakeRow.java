package com.MakeRow;

public class MakeRow {
   public boolean makeBricks(int small,int big,int goal){
	   boolean result=false ;
	   if(goal==(big*5)+small)
		    result=true;
	   else 
		    result= false;
	return result;
	}
}
