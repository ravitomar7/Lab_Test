import com.MakeRow.*;
import java.util.Scanner ; 
public class BrickTest {
    public static void main(String[] args) {
       MakeRow m=new MakeRow() ; 	
	   System.out.println("Enter the size of the brick wall(in inches)") ;
	   Scanner sc=new Scanner(System.in) ;
	   int goal=sc.nextInt() ;
	   System.out.println("Enter the no of the brick of size 5 inches") ;
	   int big=sc.nextInt() ;
	   System.out.println("Enter the no of the brick of size 1 inches") ;
	   int small=sc.nextInt() ;
	   int s,l ;
	   
	   if(m.makeBricks(small, big, goal)){
		   System.out.println("Brick row can be made");
	   }else{
		   System.out.println("Brick row cannot be made");
		   if(goal>(small+(big*5))){
			   System.out.println("Brick row made is "+(goal-(small+(big*5)))+" inches short");
		   }else if(goal<(small+(big*5))){
			   System.out.println("Brick row is "+((small+(big*5))-goal)+" inches long");
		   }
	   } 
    }
}
