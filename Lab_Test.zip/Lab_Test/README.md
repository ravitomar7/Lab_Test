# Lab-Test

> x Questions will be given on the day of the test.

> Pick question according to your roll number: 
  for e.g if x=4 and last three digit of your roll no are 123 then your question no is (1+2+3)%4 + 1 = 3
  
# Pull this repository and Fill in the blanks in Readme File alongwith:

Name: 
Roll No:
SAPID: 
Batch:
Question Assigned: 


# How to code?

* Use proper coding ethics.
* Use Package.
* Use Access Modifiers Properly.
* Different file for each class.
* Folder hierachy: 
                  src/com/bao/<your_roll_no>/<your_class.java>
                  bin/com/bao/<your_roll_no>/<your_class.class>
                  
* To do all above Code in Eclipse and commit in your own repository you pulled earlier.
* Raise a merge request(thru github webpage) to me and add screenshot of output withit.
* Request should be raised within Lab timing. i.e 

              # B4 BAO - 15 April 2019 11:30-13:30Hrs
              # B3 BAO - 16 April 2019 09:30-11:30Hrs
              # B3 OGI - 17 April 2019 09:30-11:30Hrs
              
              MAX Allowable time with marks deduction is 1 Hour.
              
All the Best!!





