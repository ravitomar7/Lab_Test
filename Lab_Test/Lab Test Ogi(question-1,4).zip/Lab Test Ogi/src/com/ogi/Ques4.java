package com.ogi;
import java.io.InputStream;
import java.util.*;

public class Ques4 {

	public static void main(String[] args)     // code to check whether two strings are anagram or not
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string1");
		String s1=sc.nextLine();
		System.out.println("Enter string2");
		String s2=sc.nextLine();
		boolean s=true;
		System.out.println("Processing......");
if(s1.length()!=s2.length())             // length of string is found out here
{
	System.out.println("Not anagrams");
	s=false;
}
else
{
	char[] ArrayS1 = s1.toLowerCase().toCharArray();  
    char[] ArrayS2 = s2.toLowerCase().toCharArray();  
    Arrays.sort(ArrayS1);  
    Arrays.sort(ArrayS2);                         // pre-defined function util package to sort alphabets in order
    s= Arrays.equals(ArrayS1, ArrayS2);  
}
if(s)
{
	System.out.println("Both strings are anagrams");           // will print if s= true
}
else
{
	System.out.println("Both strings aren't anagrams");         //// will print if s= false
}
System.out.println("End");
	}

	
}
